﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JqueryWebControls
{
    public class TriggerControlItem
    {
        /// <summary>
        /// Delegate that is called by the JqueryUpdatePanle before render back the response
        /// </summary>
        /// <param name="arguments">All the hidden field hooked up to this control</param>
        /// <param name="commandName">A command name useful to discriminate the action it has to be performed</param>
        public delegate void ActionDelegate(List<HiddenField> arguments,string commandName);

        public string CommandName { get; set; }

        /// <summary>
        /// Control that raise the async post back(Es:asp button)
        /// </summary>
        public WebControl TriggerWebControl { get; set; }
        /// <summary>
        /// The JS event that has to raise the post back(Es: onclick)
        /// </summary>
        public JsEventEnum TriggerWebControlEvent { get; set; }

        /// <summary>
        /// Action needs to be execute on the server side
        /// </summary>
        public ActionDelegate PostBackAction { get; set; }

        private List<HiddenField> _postBackArguments = new List<HiddenField>();

        /// <summary>
        /// The list of the hidden fields that will be posted.
        /// </summary>
        public List<HiddenField> PostBackArguments
        {
            get { return _postBackArguments; }
            set { _postBackArguments = value; }
        }
    }

}
