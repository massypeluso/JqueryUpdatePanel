﻿

function HideProgressPanel(obj) {
    $('#' + obj).hide();
}

function ShowProgressPanel(obj) {
    $('#' + obj).show();
}


function JqueryPost(pageName,sender,trigger,jqueryPost,clientArguments,commandname) {     

    var hiddendNameValue='';
    if (clientArguments.length>0) {
        var fileds = clientArguments.split('&');
        for (var i = 1; i < fileds.length; i++) {
            if (fileds[i] != '') {
                hiddendNameValue +='|' + fileds[i] + '&' + $("#" +  fileds[i]).val();
            }
        }    
    }

    $.post(pageName, { __pagename: pageName,
                       __sender: sender,
                       __trigger: trigger,
                       __jqueryPost: 'true',
                       __clientArguments: clientArguments,
                       __hiddenFieldNamaValue: hiddendNameValue,
                       __commandName: commandname 
                       },
            function(data){
                jQuery.globalEval(data);
            });

        }

        function JqueryPostLoading(pageName, sender, trigger, jqueryPost, clientArguments, loading, commandname) {

            var hiddendNameValue = '';
            if (clientArguments.length > 0) {
                var fileds = clientArguments.split('&');
                for (var i = 1; i < fileds.length; i++) {
                    if (fileds[i] != '') {
                        hiddendNameValue += '|' + fileds[i] + '&' + $("#" + fileds[i]).val();
                    }
                }
            }
            ShowProgressPanel(loading);
            $.post(pageName, { __pagename: pageName,
                __sender: sender,
                __trigger: trigger,
                __jqueryPost: 'true',
               
                __clientArguments: clientArguments,
                __hiddenFieldNamaValue: hiddendNameValue,
                __commandName: commandname
            },
            function (data) {
                HideProgressPanel(loading);
                jQuery.globalEval(data);
            });

        }

    
