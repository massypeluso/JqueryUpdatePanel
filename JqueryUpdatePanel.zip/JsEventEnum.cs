﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JqueryWebControls
{
    public enum JsEventEnum
    {

        onblur,

        onchange,

        onclick,

        ondblclick,

        onerror,

        onfocus,

        onkeydown,

        onkeypress,

        onkeyup,

        onload,

        onmousedown,

        onmousemove,

        onmouseout,

        onmouseover,

        onmouseup,

        onresize,

        onselect,

        onunload

    }
}
