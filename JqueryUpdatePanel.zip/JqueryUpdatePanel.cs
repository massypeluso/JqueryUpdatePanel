﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JqueryWebControls
{
    [ToolboxBitmap(typeof(JqueryUpdatePanel), "IC170241.gif")]
    public class JqueryUpdatePanel : Panel
    {
        private string TriggerId { get; set; }

        private readonly List<string> _clientCallBackParameters = new List<string>();

        private bool _autoReferenceJquery = false;


        private readonly List<TriggerControlItem> _triggerControls = new List<TriggerControlItem>();
        /// <summary>
        /// Progress panel that will be showed during the async post back. It can be used to show a "loading" image to notify the user the post back is happening
        /// 
        /// </summary>
        public JqueryUpdateProgress JqueryUpdateProgress { get; set; }


        /// <summary>
        /// Client function that will be called at the end of the async post back. The function takes arguments
        /// </summary>
        public string ClientOnCallBack { get; set; }

        private bool _isJqueryPost;
        /// <summary>
        /// Paramenter that will be passed to the ClientOnCallBack function as arguments
        /// </summary>
        public List<string> ClientCallBackParameters
        {
            get { return _clientCallBackParameters; }
        }
        /// <summary>
        /// Collection of TriggerControlItem.
        /// </summary>
        public List<TriggerControlItem> TriggerControls
        {
            get { return _triggerControls; }
        }

        public bool IsJQueryPost
        {
            get
            {
                return !string.IsNullOrEmpty(HttpContext.Current.Request.Form["__jqueryPost"]);
            }
        }

        public bool AutoReferenceJquery
        {
            get { return _autoReferenceJquery; }
            set { _autoReferenceJquery = value; }
        }


        public JqueryUpdatePanel()
        {
            _isJqueryPost = false;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            string sender = HttpContext.Current.Request.Form["__sender"];
            if (sender == ClientID)
            {
                _isJqueryPost = true;
                InvokeServerActionDelegate();
            }
            AddClientEventHandler();
          

        }

        private void PopulateHiddenFields()
        {
            var jsHiddenValues = HttpContext.Current.Request.Form["__hiddenFieldNamaValue"];
            if (!string.IsNullOrEmpty(jsHiddenValues))
            {
                var values = jsHiddenValues.Split('|');
                foreach (var value in values)
                {
                    if (!string.IsNullOrEmpty(value))
                    {
                        var hiddenName = value.Split('&')[0];
                        var hiddenValue = value.Split('&')[1];
                        foreach (var control in TriggerControls)
                        {
                            foreach (var item in control.PostBackArguments)
                            {
                                if (hiddenName.Trim().ToLower().Contains(item.ID.ToLower()))
                                {
                                    item.Value = hiddenValue;
                                }
                            }
                        }
                    }
                }
            }
        }



        private void AddClientEventHandler()
        {
            if (_triggerControls == null) return;
            foreach (var triggerControl in _triggerControls)
            {
                var jsToAdd = JqueryUpdateProgress != null
                                     ? "JqueryPostLoading('" + GetPageName() +
                                       "','" + ClientID +
                                       "','" + triggerControl.TriggerWebControl.ClientID +
                                       "','true','"  +
                                       GetJavaScriptArguments(triggerControl)
                                       + "','" + JqueryUpdateProgress.ClientID + "','"+
                                       triggerControl.CommandName + "');return false"
                                     : "JqueryPost('" + GetPageName() +
                                       "','" + ClientID +
                                       "','" + triggerControl.TriggerWebControl.ClientID +
                                       "','true','"  + 
                                       GetJavaScriptArguments(triggerControl)+ 
                                       "','" + 
                                       triggerControl.CommandName + "');return false";
                AddEventHanlder(triggerControl, jsToAdd);
            }
        }

        public void JqueryDataBind()
        {
            AddClientEventHandler();
        }

        private static void AddEventHanlder(TriggerControlItem triggerControl, string jqueryPostHandler)
        {
            string triggerEvent = triggerControl.TriggerWebControlEvent.ToString();
            try
            {
                var previosHandler = string.Empty;
                if (triggerControl.TriggerWebControl.Attributes[triggerEvent] != null)
                {
                    previosHandler = triggerControl.TriggerWebControl.Attributes[triggerEvent];
                    triggerControl.TriggerWebControl.Attributes.Remove(triggerEvent);
                }
                jqueryPostHandler = previosHandler + jqueryPostHandler;
                triggerControl.TriggerWebControl.Attributes.Add(triggerEvent, jqueryPostHandler);
            }
            catch (System.ArgumentException)
            {
                throw new ArgumentException("TriggerWebControlEvent cannot be null");
            }

        }

        private string GetCommandName()
        {
            string retVal = string.Empty;
            if (_isJqueryPost)
            {
                PopulateHiddenFields();
                foreach (var control in from control in TriggerControls.ToList()
                                        let sender = HttpContext.Current.Request.Form["__trigger"]
                                        where sender == control.TriggerWebControl.ClientID
                                        select control)
                {
                    retVal = HttpContext.Current.Request.Form["commandName"] ?? string.Empty;
                }
            }
            return retVal;
        }

        private void InvokeServerActionDelegate()
        {
            var hasBeenInvoked = false;
            if (!_isJqueryPost) return;
            PopulateHiddenFields();
            foreach (var control in from control in TriggerControls.ToList()
                                    let sender = HttpContext.Current.Request.Form["__trigger"]
                                    where sender == control.TriggerWebControl.ClientID
                                    select control)
            {
                if (hasBeenInvoked == false)
                {
                    var postaction = (TriggerControlItem.ActionDelegate) control.PostBackAction.Clone();
                    postaction.Invoke(control.PostBackArguments, GetCommandName());
                    hasBeenInvoked = true;
                }
            }
        }

        private static string GetJavaScriptArguments(TriggerControlItem triggerControl)
        {
            
                var postparams = string.Empty;
                if (triggerControl.PostBackArguments.Count > 0)
                {
                    postparams = triggerControl.PostBackArguments.Aggregate(postparams, (current, item) => current + ("&" + item.ClientID.Trim()));
                }
                return postparams.Trim();      
          
        }

        private string GetPageName()
        {
            return Path.GetFileName(Page.AppRelativeVirtualPath);
        }

        private  string GetCallBackFunction()
        {
            if (string.IsNullOrEmpty(ClientOnCallBack)) return string.Empty;
            var param = "();";
            if (ClientCallBackParameters.Count > 0)
            {
                param = ClientCallBackParameters.Aggregate("(", (current, item) => current + ("'" + item + "'"));
                param += ");";
            }
            return ClientOnCallBack + param;
        }

        protected override void OnPreRender(EventArgs e)
        {

            base.OnPreRender(e);
            AddClientResource();
        }

        public void AddToRender(HtmlTextWriter writer, string callBackFunction)
        {
          RewriteRender();
        }

        private void RewriteRender()
        {
            var sb = new StringBuilder();
            var tw = new StringWriter(sb);
            var hw = new HtmlTextWriter(tw);
            RenderContents(hw);
            var htmlToAdd = sb.ToString();
            htmlToAdd = htmlToAdd.Replace("\\", "\\\\");
            htmlToAdd = htmlToAdd.Replace(Environment.NewLine, string.Empty);
            htmlToAdd = htmlToAdd.Replace(@"""", "\\\"");
            var data = @"$(""#" + ClientID + @""").html(""" + htmlToAdd + @""");";
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Write(data);
        }

        private void AddClientResource()
        {
            const string resourceName = "JqueryWebControls.JqueryController.js";
            var cs = Page.ClientScript;
            cs.RegisterClientScriptResource(typeof(JqueryUpdatePanel), resourceName);
            if (!AutoReferenceJquery) return;
            cs.RegisterClientScriptInclude("JqueryInclude", "http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js");
        }



        protected override void Render(HtmlTextWriter writer)
        {
            if (_isJqueryPost)
            {
                foreach (var control in from control in TriggerControls.ToList()
                                        let sender = HttpContext.Current.Request.Form["__trigger"]
                                        where sender.Contains(control.TriggerWebControl.ID)
                                        select control)
                {
                    AddToRender(writer, GetCallBackFunction());
                    HttpContext.Current.Response.End();
                }
            }
            base.Render(writer);
        }
    }
}
