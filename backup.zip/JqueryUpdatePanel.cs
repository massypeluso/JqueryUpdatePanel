﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JqueryWebControls
{
    [ToolboxBitmap(typeof(JqueryUpdatePanel), "IC170241.gif")]
    public class JqueryUpdatePanel : Panel
    {
       

        public JqueryUpdateProgress JqueryUpdateProgress { get; set; }

      


        private readonly Dictionary<string, string> _postParameters = new Dictionary<string, string>();

        public Dictionary<string, string> PostParameters
        {
            get
            {
                return _postParameters;
            }
        }

        private readonly List<TriggerControlItem> _triggerControls = new List<TriggerControlItem>();

        public bool IsJqueryPost { get; set; }
        private string TriggerId { get; set; }

        public List<TriggerControlItem> TriggerControls
        {
            get { return _triggerControls; }
        }


        public JqueryUpdatePanel()
        {
            IsJqueryPost = false;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            string sender = HttpContext.Current.Request.Form["__sender"];
            if (sender == ClientID)
            {
                IsJqueryPost = true;
                InvokeServerActionDelegate();
            }
            AddClientEventHandler();
          

        }

        public void PopulateHiddenFields()
        {
           
            var jsHiddenValues = HttpContext.Current.Request.Form["__hiddenFieldNamaValue"];
            if (!string.IsNullOrEmpty(jsHiddenValues))
            {
                var values = jsHiddenValues.Split('|');
                foreach (var value in values)
                {
                    if (!string.IsNullOrEmpty(value))
                    {
                        var hiddenName = value.Split('&')[0];
                        var hiddenValue = value.Split('&')[1];
                        foreach(var control in TriggerControls)
                        {
                            if (control.JavascriptArgument==false) continue;
                            foreach (var item in control.JavaScriptArgumentFields)
                            {
                                if (item.ClientID.ToLower() == hiddenName.Trim().ToLower())
                                {
                                    item.Value = hiddenValue;
                                }
                            }
                        }
                       
                    }
                }
            }
        }

        //private void PopulateServerArguments()
        //{
        //    var jsHiddenValues = HttpContext.Current.Request.Form["__serverArgument"];
        //    if (!string.IsNullOrEmpty(jsHiddenValues))
        //    {
        //        var values = jsHiddenValues.Split('&');
        //        foreach (var value in values)
        //        {
        //            if (!string.IsNullOrEmpty(value))
        //            {
        //                var hiddenName = value.Split('=')[0];
        //                var hiddenValue = value.Split('=')[1];
        //                foreach (var item in this.PostParameters)
        //                {
        //                    if (item.Key == hiddenName.Trim().ToLower())
        //                    {

        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        private void AddClientEventHandler()
        {
            if (_triggerControls == null) return;
            foreach (var triggerControl in _triggerControls)
            {
                var jsToAdd = JqueryUpdateProgress != null
                                     ? "JqueryPostLoading('" + GetPageName() +
                                       "','" + ClientID +
                                       "','" + triggerControl.TriggerWebControl.ClientID +
                                       "','true','" +
                                       GetServerArguments() +
                                       "','" + GetJavaScriptArguments(triggerControl)
                                       + "','" + JqueryUpdateProgress.ClientID + "','"+
                                       triggerControl.CommandName + "');return false"
                                     : "JqueryPost('" + GetPageName() +
                                       "','" + ClientID +
                                       "','" + triggerControl.TriggerWebControl.ClientID +
                                       "','true','" +
                                       GetServerArguments() +
                                       "','" + GetJavaScriptArguments(triggerControl)+ 
                                       "','" + 
                                       triggerControl.CommandName + "');return false";
                AddEventHanlder(triggerControl, jsToAdd);
            }
        }

        public void JqueryDataBind()
        {
            AddClientEventHandler();
           // InvokeServerActionDelegate();
        //  RewriteRender();
        }

        private static void AddEventHanlder(TriggerControlItem triggerControl, string jqueryPostHandler)
        {
            string triggerEvent = triggerControl.TriggerWebControlEvent;
            try
            {
                string previosHandler = string.Empty;
                if (triggerControl.TriggerWebControl.Attributes[triggerEvent] != null)
                {
                    previosHandler = triggerControl.TriggerWebControl.Attributes[triggerEvent];
                    triggerControl.TriggerWebControl.Attributes.Remove(triggerEvent);
                }
                jqueryPostHandler = previosHandler + jqueryPostHandler;
                triggerControl.TriggerWebControl.Attributes.Add(triggerEvent, jqueryPostHandler);
            }
            catch (System.ArgumentException)
            {

                throw new ArgumentException("TriggerWebControlEvent cannot be null");
            }

        }

        private string GetCommandName()
        {
            string retVal = string.Empty;
            if (IsJqueryPost)
            {
                PopulateHiddenFields();
                foreach (var control in from control in TriggerControls.ToList()
                                        let sender = HttpContext.Current.Request.Form["__trigger"]
                                        where sender == control.TriggerWebControl.ClientID
                                        select control)
                {
                    retVal = HttpContext.Current.Request.Form["commandName"] ?? string.Empty;
                }
            }
            return retVal;
        }

        private void InvokeServerActionDelegate()
        {
            bool invoked = false;
            if (IsJqueryPost)
            {
                PopulateHiddenFields();
                foreach (var control in from control in TriggerControls.ToList()
                                        let sender = HttpContext.Current.Request.Form["__trigger"]
                                        where sender == control.TriggerWebControl.ClientID
                                        select control)
                {
                    var postaction = (TriggerControlItem.ActionDelegate)control.PostBackActions.Clone();
                    if (invoked==false)
                    {
                        postaction.Invoke(control.JavaScriptArgumentFields, GetCommandName());
                        invoked = true;
                    }


                }
            }
        }

        private  string GetServerArguments()
        {
            var postparams = string.Empty;
            if (PostParameters.Count > 0)
            {
              //  postparams = PostParameters.Aggregate(postparams, (current, item) => current + ("&" + item.Key + "=" + item.Value));
            }
            return postparams;
        }

        private string GetJavaScriptArguments(TriggerControlItem triggerControl)
        {
            
                var postparams = string.Empty;
                if (triggerControl.JavaScriptArgumentFields.Count > 0)
                {
                    postparams = triggerControl.JavaScriptArgumentFields.Aggregate(postparams, (current, item) => current + ("&" + item.ClientID.Trim()));
                }
                return postparams.Trim();      
          
        }

        private string GetPageName()
        {
            string retVal = Page.ToString();
            if (!string.IsNullOrEmpty(retVal))
            {
                retVal = retVal.Remove(0, 4);
                retVal = retVal.Replace("_", ".");
            }
            return retVal;
        }

        private static string GetCallBackFunction(TriggerControlItem crtl)
        {
            if (string.IsNullOrEmpty(crtl.ClientOnCallBack)) return string.Empty;
            var param = "();";
            if (crtl.ClientCallBackParameters.Count > 0)
            {
                param = crtl.ClientCallBackParameters.Aggregate("(", (current, item) => current + ("'" + item + "'"));
                param += ");";
            }
            return crtl.ClientOnCallBack + param;
        }

        protected override void OnPreRender(EventArgs e)
        {

            base.OnPreRender(e);
            AddClientResource();
        }

        public void AddToRender(HtmlTextWriter writer, string callBackFunction)
        {
          RewriteRender();
        }

        private void RewriteRender()
        {
            var sb = new StringBuilder();
            var tw = new StringWriter(sb);
            var hw = new HtmlTextWriter(tw);
            this.RenderContents(hw);
            var htmlToAdd = sb.ToString();
            htmlToAdd = htmlToAdd.Replace("\\", "\\\\");
            htmlToAdd = htmlToAdd.Replace(Environment.NewLine, string.Empty);
            htmlToAdd = htmlToAdd.Replace(@"""", "\\\"");
            var data = @"$(""#" + ClientID + @""").html(""" + htmlToAdd + @""");";
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Write(data);
        }

        private void RewriteRender(string callBackFunction)
        {
            var sb = new StringBuilder();
            var tw = new StringWriter(sb);
            var hw = new HtmlTextWriter(tw);
            //var controls = Controls.OfType<WebControl>();
            this.RenderContents(hw);
            var htmlToAdd = sb.ToString();
            htmlToAdd = htmlToAdd.Replace("\\", "\\\\");
            htmlToAdd = htmlToAdd.Replace(Environment.NewLine, string.Empty);
            htmlToAdd = htmlToAdd.Replace(@"""", "\\\"");
            var data = @"$(""#" + ClientID + @""").html(""" + htmlToAdd + @""");" + callBackFunction;
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Write(data);
        }

        private void AddClientResource()
        {
            const string resourceName = "JqueryWebControls.JqueryController.js";
            var cs = Page.ClientScript;
            cs.RegisterClientScriptResource(typeof(JqueryUpdatePanel), resourceName);
            cs.RegisterClientScriptInclude("JqueryInclude", "http://ajax.googleapis.com/ajax/libs/jquery/1.2.6/jquery.min.js");
        }



        protected override void Render(HtmlTextWriter writer)
        {
            if (IsJqueryPost)
            {
                foreach (var control in from control in TriggerControls.ToList()
                                        let sender = HttpContext.Current.Request.Form["__trigger"]
                                        where sender.Contains(control.TriggerWebControl.ID)
                                        select control)
                {
                    AddToRender(writer, GetCallBackFunction(control));
                    HttpContext.Current.Response.End();
                }
            }
            base.Render(writer);
        }
    }
}
