﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace JqueryWebControls
{
    public class TriggerControlItem
    {
        public delegate void ActionDelegate(List<HiddenField> arguments,string commandName);

        private readonly List<string> _clientCallBackParameters = new List<string>();

        public string ClientOnCallBack { get; set; }

        public string CommandName { get; set; }

        public bool JavascriptArgument { set; get; }

        public WebControl TriggerWebControl { get; set; }

        public string TriggerWebControlEvent { get; set; }

        private List<HiddenField> _javaScriptArgumentFields = new List<HiddenField>();

        public List<HiddenField> JavaScriptArgumentFields
        {
            get { return _javaScriptArgumentFields; }
            set { _javaScriptArgumentFields = value; }
        }


        public ActionDelegate PostBackActions { get; set; }

        public List<string> ClientCallBackParameters
        {
            get { return _clientCallBackParameters; }
        }
    }

}
